package Model;

import java.util.Scanner;

import Control.ContaNullException;

/**
 * @author cleefsouza
 *
 */

public class Main {
	static Scanner ent;
	public static void main(String[] args) {		
		Endereco endereco = new Endereco("Amazing Grace", "58302-000", "Throwable", "256b", "Hole Java");
		Agencia agencia = new Agencia("1234-5", endereco);
		
		Conta conta;		
		

		while (true) {
			System.out.print(
					"-----------------------\nGerenciamento de Contas\n-----------------------\n1 - Cadastrar Conta\n2 - Listar Contas\n3 - Acessar uma Conta\n4 - Sair\n>>> ");
			
			ent = new Scanner(System.in); // Zerando objeto Scanner
			String opc = ent.nextLine();

			switch (opc) {
				case "1":
					System.out.println("N�mero da conta >>> ");
					String numeroConta = ent.next(); // Ex: 12345-6
					
					System.out.println("Senha da conta >>> ");
					String senha = ent.next(); // Ex: abc123
					
					System.out.println("Saldo atual >>> ");
					double saldo = ent.nextDouble(); // Ex: 1200.0
					
					conta = new Conta(numeroConta, senha, saldo); // Criando conta
					try {
						 // Cadastrando conta na ag�ncia
						agencia.cadastrarConta(conta);
					} catch (ContaNullException cne) {
						System.err.println("Erro: "+cne.getMessage());
					}
					break;
					
				case "2":
					agencia.listarContas(); // Listando contas
					break;
					
				case "3":
					agencia.acessarConta(ent.next()); // Acessando uma conta
					break;
					
				case "4":
					System.out.println(">>> Obrigado por utilizar o Unip� Bank!\n>>> Encerrando ...");
					System.exit(1);
					break;
					
				default:
					System.out.println(">>> Op��o inv�lida!");
					break;
			}
		}
	}
}
