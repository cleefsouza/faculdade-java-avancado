package Control;

/**
 * @author cleefsouza
 *
 */

public class ContaNullException extends Exception {
	// Construtor
	public ContaNullException(String msg) {
		super(msg); // Mensagem que ser� enviada para a classesuper
	}
}
