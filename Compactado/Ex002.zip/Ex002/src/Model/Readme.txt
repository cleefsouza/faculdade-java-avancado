Exercic�o:

Crie um programa que implemente composi��o.
Para isto, suponha que voc� foi contratado por um fabricante de carros.
Crie as seguintes classes, com os m�todos e atributos necess�rios:

-Pneus (pre�o, aro, fabricante)
-Motor (pot�ncia, pre�o, fabricante)
-Bancos (pre�o, modelo, fabricante)
-Carro (que � a agrega��o das classes Pneus, Motor e Bancos)

-Instancie 3 objetos da classe Carro. Ap�s instanciar um carro, imprima o seu pre�o (pre�o do pneu + pre�o motor + pre�o do bancos).
-Todos os atributos devem estar encapsulados e com seus respectivos m�todos seletores e modificadores.
