Exercicio:

Crie uma agenda telef�nica em Java

Opera��es:
1 - Inserir
2 - Alterar
3 - Remover
4 - Listar
5 - Procurar por Nome
6 - Procurar por Telefone

Classes:
1 - Contato (cpf, nome, telefone)
2 - Agenda (lista de comandos)
