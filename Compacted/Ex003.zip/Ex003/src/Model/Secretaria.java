package Model;

public class Secretaria extends Funcionario{
	private int numeroRamal;
	
	/*
	 * Getters e Setters 
	 */
	
	public int getNumeroRamal() {
		return numeroRamal;
	}

	public void setNumeroRamal(int numeroRamal) {
		this.numeroRamal = numeroRamal;
	}
	
}
