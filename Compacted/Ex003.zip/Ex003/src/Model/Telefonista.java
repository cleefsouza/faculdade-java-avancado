package Model;

public class Telefonista extends Funcionario{
	private int codigoEstacao;
	
	/*
	 * Getters e Setters 
	 */
	
	public int getCodigoEstacao() {
		return codigoEstacao;
	}

	public void setCodigoEstacao(int codigoEstacao) {
		this.codigoEstacao = codigoEstacao;
	}
	
	
}
