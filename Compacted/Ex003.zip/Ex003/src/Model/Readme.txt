Exercic�os:

Defina uma classe para modelar os funcion�rios do banco.
Sabendo que todo funcion�rio possui nome e sal�rio, inclua os getters e setters dos atributos.

Crie uma classe para cada tipo espec�fico de funcion�rio herdando da classe Funcion�rio.
Considere apenas tr�s tipos especificos de funcion�rios:

- Gerentes
- Telefonistas
- Secretarias

- Os gerentes possuem um nome de usu�rio e uma senha para acessar o sistema do banco.
- As telefonistas possuem um c�digo de esta��o de trabalho.
- As secretarias possuem um n�mero de ramal.

Crie uma classe Main e teste o funcionamento dos tr�s tipos de funcion�rios criando um objeto
de cada uma das classes.

Suponha que todos os funcion�rios recebam uma bonifica��o de 10% do sal�rio.
Acrescente um m�todo calculaBonificacao() na classe pai para realizar esse calculo.

Altere a classe Main para imprimir a bonifica��o de cada funcion�rio, al�m dos dados que j� foram impressos.
Suponha que os gerentes recebam uma bonifica��o maior que os outros, ou seja 60%.
Reescreva o metodo na classe Gerente.