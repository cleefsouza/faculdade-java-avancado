Exercic�o:

Considere o problema de uma idade menor ou igual a zero.

a) Crie uma classe Pessoa com os atributos nome e idade, com seus respectivos seletores e modificadores.

b) Crie uma exce��o chamada IdadeException que herda de Exception

c) Reescreva o modificar (set) de idade para aceitar apenas idades maiores que zero,
se uma idade menor que zero for digitada uma exce��o IdadeException dever� ser lan�ada.

d) Teste o m�todo para verificar se a exce��o est� sendo lan�ada e trate-a.

e) Elabore a l�gica de ficar repetindo a pergunta ao usu�rio enquanto ele n�o digitar uma idade maior que zero.