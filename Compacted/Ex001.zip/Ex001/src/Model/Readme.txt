Exercic�o:

Crie um programa que cadastre uma compra de determinada pessoa depois imprima os valores atribu�dos aos seus atributos.
Cada compra possui uma Pessoa e um Produto. No entanto, o produto possui c�digo e nome.
J� Pessoa, possui nome, endere�o e cpf. Lembrando que endere�o tamb�m possui atributos que � rua, n�mero, bairro, cidade, cep e complemento.