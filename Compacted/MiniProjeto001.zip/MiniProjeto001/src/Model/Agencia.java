package Model;

public class Agencia {

}
