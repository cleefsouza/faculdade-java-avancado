package Model;

public class Conta {

}
